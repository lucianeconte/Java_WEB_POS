package br.edu.unoesc.webmob.eleicao.model;

/**
 * Interface de valida��o
 * @author Roberson Alves
 *
 */
public interface Validador {
	public boolean validarDocumento(Long numero);
}
